<?php
echo "TEST FILE WORKS!";
echo "\u003cbr\u003ePHP Version: " . PHP_VERSION;
echo "\u003cbr\u003eCurrent Dir: " . __DIR__;
echo "\u003cbr\u003eBase URL should be: http://localhost/Food-order-website-master/public/";
